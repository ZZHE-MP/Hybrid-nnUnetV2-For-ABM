import setuptools

if __name__ == "__main__":
    setuptools.setup()
