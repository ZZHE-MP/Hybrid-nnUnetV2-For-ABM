from batchgenerators.utilities.file_and_folder_operations import *
import shutil
from nnunetv2.dataset_conversion.generate_dataset_json import generate_dataset_json
from nnunetv2.paths import nnUNet_raw

if __name__ == '__main__':
    """
    Download the dataset from huggingface:
    https://huggingface.co/datasets/AbdomenAtlas/_AbdomenAtlas1.1Mini#3--download-the-dataset
    
    IMPORTANT
    cases 5196-9262 currently do not have images, just the segmentation. This seems to be a mistake 
    """
    base = '/mnt/e/htnnunet+/nnUNet-master/DATASET/nnUNet_raw/Task099_abd'
    target_dataset_id = 23
    target_dataset_name = f'Dataset{target_dataset_id:03.0f}_AbdomenAtlas1.1Mini'

    cases = subdirs(base, join=False, prefix='BDMAP')

    maybe_mkdir_p(join(nnUNet_raw, target_dataset_name))
    imagesTr = join(nnUNet_raw, target_dataset_name, 'imagesTr')
    labelsTr = join(nnUNet_raw, target_dataset_name, 'labelsTr')
    maybe_mkdir_p(imagesTr)
    maybe_mkdir_p(labelsTr)

    for case in cases:
        if not isfile(join(base, case, 'ct.nii.gz')):
            print(f'Skipping case {case} due to missing image')
            continue
        shutil.copy(join(base, case, 'ct.nii.gz'), join(imagesTr, case + '_0000.nii.gz'))
        shutil.copy(join(base, case, 'combined_labels.nii.gz'), join(labelsTr, case + '.nii.gz'))

    class_map = {  1: 'spleen',          2:'portal vein and splenic vein',3: 'pancreas',4:'right adrenal gland',
                  5:'left adrenal gland',6:'right kidney',7: 'left kidney',8:'gallbladder',9: 'esophagus',10:'liver',11:'stomach',12:'aorta',
                                                                                     13:'inferior vena cava'}
    labels = {
        j: i for i, j in class_map.items()
    }
    labels['background'] = 0

    generate_dataset_json(
        join(nnUNet_raw, target_dataset_name),
        {0: 'CT'},
        labels,
        len(cases),
        '.nii.gz',
        None,
        target_dataset_name,
        overwrite_image_reader_writer='NibabelIOWithReorient',
        reference='https://huggingface.co/datasets/AbdomenAtlas/_AbdomenAtlas1.1Mini',
        license='Creative Commons Attribution Non Commercial Share Alike 4.0; see reference'
    )